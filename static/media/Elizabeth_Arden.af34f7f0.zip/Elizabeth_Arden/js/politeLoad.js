/************************************

*    Polite Load Script
*    Adrian Velazquez
*    Digital Media Developer
    --------------------
*    Adrian.Velazquez@Revlon.com
*    http://www.revlon.com/
*    @version v1.0.0

************************************/

"use strict";

function init(){

	/*
  ********** initialize banner and exit elements
  */
	var banner = document.getElementById('banner'),
	    hit = document.getElementById('hit');

	/*
  ********** add DC Exit Enabler / handler
  */
	handler();

	/*
  ********** Display banner
  */
	banner.style.display = "block";

};


/*
********** DC Exit Enabler / handler
*/
function handler() {

	/*
  ********** setup banner element with DC Enabler
  */
	hit.addEventListener('mousedown', function(){// hit exit clickThrough
		Enabler.exit('Background Exit');// dcm studio exit invocation
	});

};

/*
********** initialize polite load
*/
init();
