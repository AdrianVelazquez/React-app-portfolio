/************************************

*    Revlon 1H18-NYC-PROMO Javascript
*    Adrian Velazquez
*    Digital Media Developer
*    2018
    --------------------
*    Adrian.Velazquez@Revlon.com
*    http://www.revlon.com/
*    @version v1.0.0

************************************/
(function(){
"use strict";

  var assets;
  var tl;
  var e;
  
  /*
  ********** check for namespace existance, if defined, use, if not, assign new instance to vars
  */
  var assets = assets || {}, tl = tl || new TimelineLite(), e = e || {};

  /*
  ********** dom elements
  */
  var assets = {

    // utility assets
    banner : document.getElementById('banner'),

    // banner utilities
    utilities: {
      whiteBG : document.getElementById('whiteBG'),
      frame2BG : document.getElementById('frame2bg'),
      hit : document.getElementById('hit')
    },

    // graphic assets
    images : {
      bg : document.getElementById('bg'),
      girl : document.getElementById('girl'),
      heart : document.getElementById('heart'),
      logo : document.getElementById('logo'),
      cta : document.getElementById('cta')
    },

    // svg and mask assets
    svg : {
      mask : document.getElementById('mask'),
      svgNY : document.getElementById('svg-ny'),
      mask2 : document.getElementById('mask2'),
      svgLove : document.getElementById('svg-love')
    },

    // text assets
    text : {
      txtNY : document.getElementById('txt-ny'),
      txtWin : document.getElementById('txt-win'),
      txtDetails : document.getElementById('txt-details'),
      txtEnter : document.getElementById('txt-enter'),
      txtCTA : document.getElementById('txt-cta'),
      txtPlus : document.getElementById('txt-plus'),
      txtMarketing1 : document.getElementById('txt-marketing-1'),
      txtMarketing2 : document.getElementById('txt-marketing-2'),
      txtMarketing3 : document.getElementById('txt-marketing-3'),
      txtDisclaimer : document.getElementById('txt-disclaimer')
    }

  };

  /*
  ********** initialize the animation timeline
  */
  var tl = new TimelineLite();

  /*
  ********** ease library
  */
  var e = {
        a : "Expo.easeInOut",
        b : "Sine.easeInOut",
        c : "Back.easeInOut.config(1.7)",
        d : "Sine.easeIn",
        e : "Sine.easeOut"
      };

  /*
  ********** function that sets up banner and elements
  */
  function setup(){
    TweenLite.set(assets.banner, {autoAlpha:1, onComplete:ctaListeners});
    TweenLite.set(assets.utilities.frame2BG, {autoAlpha:1});
    TweenLite.set(assets.images.girl, {x:-250, y:50, force3D:true, z:0.1, rotationZ:0.01});
    TweenLite.set(assets.images.heart, {scale:.75, force3D:true, z:0.1, rotationZ:0.01});
    TweenLite.set(assets.svg.mask, {x:-712, force3D:true, z:0.1, rotationZ:0.01});
    TweenLite.set(assets.svg.mask2, {x:-550, force3D:true, z:0.1, rotationZ:0.01});
    TweenLite.set([
                  assets.text.txtPlus,
                  assets.text.txtMarketing1,
                  assets.text.txtMarketing2,
                  assets.text.txtMarketing3,
                  assets.text.txtDisclaimer
                ], {y:"-10", force3D:true, z:0.1, rotationZ:0.01})
  };

  /*
  ********** main heartbeat animation
  */
  function beat(){
    TweenMax.to(assets.images.heart, 1.25, {scale:.9, ease:e.d, yoyo:true, onComplete:function(){
      TweenMax.to(assets.images.heart, 1.25, {scale:1, ease:e.e, yoyo:true});
    }}).repeat(7);
  };

  /*
  ********** main animation
  */
  function setItOff(){
    // run setup function for elements
    setup();
    tl
      // frame 1
     .to(assets.images.girl, 2.5, {x:0, y:0, ease:e.a})
     .to([
          assets.utilities.whiteBG,
          assets.text.txtWin,
          assets.text.txtDetails
        ], .75, {autoAlpha:1, ease:e.b}, "-=1")
     .to(assets.text.txtWin, .75, {autoAlpha:1, ease:e.b})
     .staggerTo([assets.svg.mask, assets.svg.mask2], 1.5, {ease:e.b, force3D:true, x:0}, 0.5, "-=1.5")
     .to(assets.images.heart, .75, {autoAlpha:1, scale:1, ease:e.c, onComplete:beat}, "-=1.2")
     .to(assets.images.logo, .5, {autoAlpha:1, ease:e.d}, "-=1")
     .to([
           assets.images.bg,
           assets.images.girl,
           assets.utilities.whiteBG,
           assets.text.txtWin,
           assets.text.txtDetails,
           assets.images.heart,
           assets.svg.svgNY,
           assets.svg.svgLove
         ], 1, {autoAlpha:0, ease:e.a}, "+=3")

    // reset and setup for frame 3
    .set(assets.images.girl, {x:-250, y:50, autoAlpha:1, scale:.99})
    .set(assets.images.heart, {scale:.6, x:-104, y:-39})
    .set(assets.svg.svgNY, {scale:.6, x:-108, y:-24})
    .set(assets.svg.svgLove, {scale:.6, x:-109, y:-41})

    // frame 2
    .staggerTo([
                assets.text.txtPlus,
                assets.text.txtMarketing1,
                assets.text.txtMarketing2,
                assets.text.txtMarketing3,
                assets.text.txtDisclaimer
              ], 1.25, {autoAlpha:1, y:0, ease:e.e}, .25, "-=.5")
    .to([
         assets.utilities.frame2BG,
         assets.text.txtPlus,
         assets.text.txtMarketing1,
         assets.text.txtMarketing2,
         assets.text.txtMarketing3,
         assets.text.txtDisclaimer
       ], .5, {autoAlpha:0, ease:e.d}, "+=4")

    // frame 3
    .to(assets.images.girl, 1, {x:-33, y:0}, "-=.5")
    .to([
         assets.images.heart,
         assets.svg.svgNY,
         assets.svg.svgLove
       ], 1, {autoAlpha:1, ease:e.b}, "-=.5")
    .staggerTo([
                assets.text.txtEnter,
                assets.text.txtCTA,
                assets.text.txtDetails
              ], 1.5, {autoAlpha:1, ease:e.a}, .25, "-=.5");
  };

  /*
  ********** CTA event listeners
  */
  function ctaListeners(){
    assets.utilities.hit.addEventListener('mouseover', function(){// cta over
      // endframe heartbeat animation on hover
      TweenMax.to(assets.images.heart, 1.25, {scale:.5, ease:e.d, yoyo:true, onComplete:function(){
        TweenMax.to(assets.images.heart, 1.25, {scale:.6, ease:e.e, yoyo:true});
      }}).repeat(2);
    });

  };

  /*
  ********** Initialize the animation
  */
  setItOff();
})();
